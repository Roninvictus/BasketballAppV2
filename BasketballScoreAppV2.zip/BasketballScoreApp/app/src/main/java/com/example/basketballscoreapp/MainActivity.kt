package com.example.basketballscoreapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    private lateinit var scoreText: TextView
    private lateinit var scoreText2: TextView
    private lateinit var score1A: Button
    private lateinit var score1B: Button
    private lateinit var score2A: Button
    private lateinit var score2B: Button
    private lateinit var score3A: Button
    private lateinit var score3B: Button
    private lateinit var resetButton: Button
    private var countA = 0
    private var countB = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        scoreText = findViewById(R.id.score_text1)
        scoreText2 = findViewById(R.id.score_text2)
        score1A = findViewById(R.id.button1)
        score2A = findViewById(R.id.button2)
        score3A = findViewById(R.id.button3)
        score1B = findViewById(R.id.button1_2)
        score2B = findViewById(R.id.button2_2)
        score3B = findViewById(R.id.button3_2)
        resetButton = findViewById(R.id.button_reset)

        score1A.setOnClickListener {
            addOnePoint("A")
        }

        score2A.setOnClickListener {
            addTwoPoints("A")
        }

        score3A.setOnClickListener {
            addThreePoints("A")
        }

        score1B.setOnClickListener {
            addOnePoint("B")
        }

        score2B.setOnClickListener {
            addTwoPoints("B")
        }

        score3B.setOnClickListener {
            addThreePoints("B")
        }

        resetButton.setOnClickListener {
            resetScore()
        }
    }

    private fun addOnePoint(teamName: String) {
        if (teamName == "A") {
            countA++
            scoreText.text = countA.toString()
        } else {
            countB++
            scoreText2.text = countB.toString()
        }
    }

    private fun addTwoPoints(teamName: String) {
        if (teamName == "A") {
            countA += 2
            scoreText.text = countA.toString()
        } else {
            countB += 2
            scoreText2.text = countB.toString()
        }
    }

    private fun addThreePoints(teamName: String) {
        if (teamName == "A") {
            countA += 3
            scoreText.text = countA.toString()
        } else {
            countB += 3
            scoreText2.text = countB.toString()
        }
    }

    private fun resetScore() {
        countA = 0
        countB = 0
        scoreText.text = "0"
        scoreText2.text = "0"
    }
}
